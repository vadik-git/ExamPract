﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExamDownFile
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

   


    public partial class MainWindow : Window
    {
        public void UpdateFolder()
        {
            string[] files = Directory.GetFiles("C:/Users/Vadim/Desktop/BadFiles");
            ListBoxItemsFolder.Items.Clear();
            foreach (var i in files)
            {
                var file = new MyFile { Title = System.IO.Path.GetFileName(i), Path = System.IO.Path.GetFullPath(i) };

                ListBoxItemsFolder.Items.Add(file);
            }
        }
        public void UpdateFolderMove(string path)
        {
            string[] files = Directory.GetFiles(path);
            ListMoveFile.Items.Clear();
            foreach (var i in files)
            {
                var file = new MyFile { Title = System.IO.Path.GetFileName(i), Path = System.IO.Path.GetFullPath(i) };

                ListMoveFile.Items.Add(file);
            }
        }

        public void DownloadFile(object obj)
        {
            MyFileInfo file = obj as MyFileInfo;
            WebClient client = new WebClient();
            string target = System.IO.Path.Combine(file.pathDownloadTo, file.NameFile);

            //client.DownloadProgressChanged += Client_DownloadProgressChanged;

            // file.Procent = data;
           // string fileName = System.IO.Path.GetFileName(file.adressFile);

            client.DownloadFile(new Uri(file.adressFile), target);


        }

        public MainWindow()
        {
            InitializeComponent();
            ListBoxItemsFolder.DisplayMemberPath = "Title";
            ListBoxItemsFolder.SelectedValuePath = "Path";
            ListMoveFile.DisplayMemberPath = "Title";
            ListMoveFile.SelectedValuePath = "Path";

            UpdateFolder();
            UpdateFolderMove("C:/Users/Vadim/Desktop/FolderMove");
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            { 
                var item = ListBoxItemsFolder.SelectedItems.Cast<MyFile>();
                var path = string.Join(Environment.NewLine, item.Select(x => x.Path));
                File.Delete(path);
                UpdateFolder();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
               
                   MyFileInfo info = new MyFileInfo()
                   {
                        NameFile = $"{1}-{TbNameFile.Text}",
                        adressFile = TbPathDownFile.Text,
                        pathDownloadTo = TbPathSaveFolder.Text,
                        

                   };

                ListDownFile.Items.Add(info);
                ThreadPool.QueueUserWorkItem(DownloadFile, info);
                UpdateFolder();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = ListBoxItemsFolder.SelectedItems.Cast<MyFile>();
                var path = string.Join(Environment.NewLine, item.Select(x => x.Path));
                File.Move(path, $"C:/Users/Vadim/Desktop/BadFiles/{TbNameFile.Text}");
                UpdateFolder();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                var item = ListBoxItemsFolder.SelectedItems.Cast<MyFile>();
                var path = string.Join(Environment.NewLine, item.Select(x => x.Path));
                File.Move(path, "C:/Users/Vadim/Desktop/FolderMove");
                UpdateFolder();
                UpdateFolderMove("C:/Users/Vadim/Desktop/FolderMove");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
